package org.aospbased.settings;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import androidx.appcompat.app.AppCompatActivity;
import org.aospbased.settings.databinding.LayoutAdditionalBinding;
public class additional extends AppCompatActivity {
    private LayoutAdditionalBinding addon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addon = LayoutAdditionalBinding.inflate(getLayoutInflater());
        setContentView(addon.getRoot());
        setSupportActionBar(addon.addon);
        addon.datt.setOnClickListener(v ->{
                Intent h1 = new Intent(Settings.ACTION_DATE_SETTINGS);
                startActivity(h1);
        });
        addon.devo.setOnClickListener(v ->{
                Intent h1 = new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS);
                startActivity(h1);
        });
        addon.access.setOnClickListener(v ->{
                Intent h1 = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                startActivity(h1);
        });
        addon.key.setOnClickListener(v ->{
                Intent h1 = new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS);
                startActivity(h1);
        });
        addon.lang.setOnClickListener(v ->{
                Intent h1 = new Intent(Settings.ACTION_LOCALE_SETTINGS);
                startActivity(h1);
        });
    }
}
