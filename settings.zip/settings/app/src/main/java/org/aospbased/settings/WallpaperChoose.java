package org.aospbased.settings;

import android.app.WallpaperManager;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.IOException;
import android.os.Bundle;
import android.view.View;
import android.annotation.SuppressLint;
import androidx.appcompat.app.AppCompatActivity;
import org.aospbased.settings.databinding.LayoutWallpaperChooseBinding;

public class WallpaperChoose extends AppCompatActivity {
    private LayoutWallpaperChooseBinding chose;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        chose = LayoutWallpaperChooseBinding.inflate(getLayoutInflater());
        setContentView(chose.getRoot());
        setSupportActionBar(chose.star);
        final WallpaperManager wallpaperManager =
                WallpaperManager.getInstance(getApplicationContext());
        chose.star.setNavigationOnClickListener(
                v -> {
                    onBackPressed();
                });
        chose.oneui1.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.oneui1,WallpaperManager.FLAG_SYSTEM);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.oneui2.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.oneui2,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {

                            e.printStackTrace();
                        }
                    }
                });
        chose.oneui3.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.oneui3,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.oneui4.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.oneui4,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.oneui5.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.oneui5,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.oppo1.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.oppo1,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.oppo2.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.oppo2,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.oppo3.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.oppo3,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.oppo4.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.oppo4,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.oppo5.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.oppo5,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.oppo6.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.oppo6,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.oppo7.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.oppo7,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
       chose.oppo8.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.oppo8,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.oppo9.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.oppo9,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.hono1.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.hono1,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.hono2.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.hono2,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.hono3.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.hono3,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.hono4.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.hono4,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.xio1.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.xio1,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.xio2.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.xio2,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.xio3.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.xio3,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
       chose.xio4.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.xio4,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.xio5.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.xio5,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
        chose.xio6.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.xio6,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
       chose.xio7.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.xio7,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
       chose.xio8.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    @Override
                    public void onClick(View v) {

                        try {
                            wallpaperManager.setResource(R.drawable.xio8,WallpaperManager.FLAG_SYSTEM);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
    }
}
