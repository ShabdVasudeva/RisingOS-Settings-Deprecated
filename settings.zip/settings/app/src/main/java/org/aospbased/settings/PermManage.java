package org.aospbased.settings;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import androidx.appcompat.app.AppCompatActivity;
import org.aospbased.settings.databinding.LayoutPermManageBinding;

public class PermManage extends AppCompatActivity {
    private LayoutPermManageBinding permission;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        permission = LayoutPermManageBinding.inflate(getLayoutInflater());
        setContentView(permission.getRoot());
        setSupportActionBar(permission.perm);
        permission.modify.setOnClickListener(v ->{
            Intent modify = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                startActivity(modify);
        });
        permission.access.setOnClickListener(v ->{
            Intent not = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                startActivity(not);
        });
        permission.file.setOnClickListener(v ->{
           Intent file = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                startActivity(file); 
        });
        permission.ab.setOnClickListener(v ->{
            Intent ab = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
                startActivity(ab);
        });
        permission.perm.setNavigationOnClickListener(v ->{
           onBackPressed(); 
        });
    }
}
