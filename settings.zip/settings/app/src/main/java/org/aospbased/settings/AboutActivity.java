package org.aospbased.settings;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import org.aospbased.settings.databinding.ActivityAboutBinding;
public class AboutActivity extends AppCompatActivity {
    private ActivityAboutBinding binding2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding2 = ActivityAboutBinding.inflate(getLayoutInflater());
        setContentView(binding2.getRoot());
        setSupportActionBar(binding2.aboutool);
        binding2.aboutool.setNavigationOnClickListener(v ->{
            onBackPressed();
        });
        binding2.devicename.setText(android.os.Build.MODEL);
        binding2.security.setText(android.os.Build.VERSION.SECURITY_PATCH);
        binding2.kernel.setText(android.os.Build.VERSION.CODENAME);
    }
}