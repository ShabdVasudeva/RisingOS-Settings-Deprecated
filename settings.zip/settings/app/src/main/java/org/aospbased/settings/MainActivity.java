package org.aospbased.settings;

import android.animation.IntEvaluator;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Context;
import android.content.IntentFilter;
import android.content.Intent;
import android.graphics.Color;
import android.content.DialogInterface;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.EditText;
import android.text.InputType;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.snackbar.Snackbar;
import java.io.File;
import android.os.Environment;
import android.os.StatFs;
import java.text.DecimalFormat;
import org.aospbased.settings.additional;
import org.aospbased.settings.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);
        binding.user.setOnClickListener(
                v -> {
                    Intent add = new Intent(Settings.ACTION_ADD_ACCOUNT);
                    startActivity(add);
                });
        binding.welcome.setText("Welcome back " + android.os.Build.BRAND + " user");
        this.registerReceiver(
                this.mBatInfoReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = this.registerReceiver(null, ifilter);
        Intent batteryTechnology = this.registerReceiver(null, ifilter);
        int status =
                batteryStatus != null
                        ? batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                        : -1;
        boolean isCharging =
                status == BatteryManager.BATTERY_STATUS_CHARGING
                        || status == BatteryManager.BATTERY_STATUS_FULL;
        if (isCharging) {
            binding.textper.setText("charging");
        } else {
            binding.textper.setText("discharging");
        }
        StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getPath());
        long bytesAvailable;
        bytesAvailable = stat.getBlockSizeLong() * stat.getAvailableBlocksLong();
        long megAvailable = bytesAvailable / (1024 * 1024 * 1024);
        int value = (int) megAvailable;
        binding.progressbar2.setProgress(value);
        binding.aboutphn.setOnClickListener(
                v -> {
                    Intent intent = new Intent(this, AboutActivity.class);
                    startActivity(intent);
                });
        binding.search.setOnClickListener(
                v -> {
                    Intent intent2 = new Intent(Settings.ACTION_APP_SEARCH_SETTINGS);
                    startActivity(intent2);
                });
        binding.personalizations.setOnClickListener(
                v -> {
                    Intent custom = new Intent(this, Personalisation.class);
                    startActivity(custom);
                });
        binding.network.setOnClickListener(
                v -> {
                    Intent ig = new Intent(Settings.ACTION_WIRELESS_SETTINGS);
                    startActivity(ig);
                });
        binding.home.setOnClickListener(
                v -> {
                    Intent home = new Intent(Settings.ACTION_HOME_SETTINGS);
                    startActivity(home);
                });
        binding.display.setOnClickListener(
                v -> {
                    Intent display = new Intent(Settings.ACTION_DISPLAY_SETTINGS);
                    startActivity(display);
                });
        binding.sound.setOnClickListener(
                v -> {
                    Intent sound = new Intent(Settings.ACTION_SOUND_SETTINGS);
                    startActivity(sound);
                });
        binding.storage.setOnClickListener(
                v -> {
                    Intent storage = new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS);
                    startActivity(storage);
                });
        binding.security.setOnClickListener(
                v -> {
                    Intent locks = new Intent(Settings.ACTION_SECURITY_SETTINGS);
                    startActivity(locks);
                });
        binding.privacy.setOnClickListener(
                v -> {
                    Intent privat = new Intent(Settings.ACTION_PRIVACY_SETTINGS);
                    startActivity(privat);
                });
        binding.location.setOnClickListener(
                v -> {
                    Intent location = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                    startActivity(location);
                });
        binding.account.setOnClickListener(
                v -> {
                    Intent account = new Intent(Settings.ACTION_SYNC_SETTINGS);
                    startActivity(account);
                });
        binding.wellbeing.setOnClickListener(
                v -> {
                    Intent wellb = new Intent();
                    wellb.setClassName(
                            "com.google.android.apps.wellbeing",
                            "com.google.android.apps.wellbeing.settings.TopLevelSettingsActivity");
                    startActivity(wellb);
                });

        binding.notify.setOnClickListener(
                v -> {
                    Intent notify = new Intent(Settings.ACTION_ALL_APPS_NOTIFICATION_SETTINGS);
                    startActivity(notify);
                });
        binding.apw.setText(android.os.Build.BRAND + " " + android.os.Build.MODEL);
        binding.bat2.setOnClickListener(v ->{
            Intent bat = new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS);
                startActivity(bat);
        });
        binding.clean.setOnClickListener(v ->{
            Intent clean = new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS);
                startActivity(clean);
        });
        binding.search2.setOnClickListener(v ->{
            Intent se = new Intent(Settings.ACTION_APP_SEARCH_SETTINGS);
                startActivity(se);
        });
        binding.Bluetooth.setOnClickListener(v ->{
            Intent bt = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
                startActivity(bt);
        });
        binding.battery.setOnClickListener(v ->{
            Intent ba = new Intent();
                ba.setClassName("org.aospbased.battery",
                    "org.aospbased.battery.MainActivity");
                startActivity(ba);
        });
        binding.about.setOnClickListener(v ->{
            Intent ab = new Intent(this,AboutActivity.class);
                startActivity(ab);
        });
        binding.apps.setOnClickListener(v ->{
            Intent ap = new Intent(this,Apps.class);
                startActivity(ap);
        });
        binding.tunesystem.setOnClickListener(v ->{
            Intent tune = new Intent(this,WallpaperStyle.class);
                startActivity(tune);
        });
        binding.addition.setOnClickListener(v ->{
           Intent adds = new Intent(this,additional.class);
                startActivity(adds); 
        });
    }

    private BroadcastReceiver mBatInfoReceiver =
            new BroadcastReceiver() {
                @Override
                public void onReceive(Context ctxt, Intent intent) {
                    int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                    int batteryPct = level * 100 / (int) scale;
                    binding.progressbar.setProgress(batteryPct);
                    binding.pre.setText(String.valueOf(batteryPct) + " Percent");
                }
            };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        this.binding = null;
    }
}
