package org.aospbased.settings;

import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.widget.Toast;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.ParcelFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Build;
import android.provider.Settings;
import androidx.annotation.RequiresApi;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import org.aospbased.settings.databinding.LayoutPersonalisationBinding;

public class Personalisation extends AppCompatActivity {
    private LayoutPersonalisationBinding hello;
    private WallpaperManager wallpaperManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hello = LayoutPersonalisationBinding.inflate(getLayoutInflater());
        setContentView(hello.getRoot());
        setSupportActionBar(hello.person);
        hello.person.setNavigationOnClickListener(
                v -> {
                    onBackPressed();
                });
        hello.theme.setOnClickListener(
                v -> {
                    PackageManager pm = getPackageManager();
                    Intent intent =
                            pm.getLaunchIntentForPackage("com.google.android.apps.wallpaper");
                    startActivity(intent);
                });
        hello.wallstyl.setOnClickListener(v -> {
                Intent i = new Intent(this,WallpaperStyle.class);
                startActivity(i);
        });
        hello.tunesystem.setOnClickListener(v ->{
            Intent tune = new Intent();
                tune.setClassName("com.android.systemui",
                    "com.android.systemui.DemoMode");
                startActivity(tune);
        });
        hello.wallstyl.setOnClickListener(v ->{
            Intent walls = new Intent(this,WallpaperStyle.class);
                startActivity(walls);
        });
    }
}
