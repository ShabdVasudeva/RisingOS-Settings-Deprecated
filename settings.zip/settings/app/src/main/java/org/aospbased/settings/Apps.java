package org.aospbased.settings;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import androidx.appcompat.app.AppCompatActivity;
import org.aospbased.settings.databinding.LayoutAppsBinding;

public class Apps extends AppCompatActivity {
    private LayoutAppsBinding apps;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        apps = LayoutAppsBinding.inflate(getLayoutInflater());
        setContentView(apps.getRoot());
        setSupportActionBar(apps.apps456);
        apps.manage.setOnClickListener(v ->{
            Intent manage = new Intent(Settings.ACTION_APPLICATION_SETTINGS);
                startActivity(manage);
        });
        apps.defau.setOnClickListener(v ->{
            Intent defau = new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS);
            startActivity(defau);
        });
        apps.quick.setOnClickListener(v ->{
            Intent home = new Intent(Settings.ACTION_HOME_SETTINGS);
                startActivity(home);
        });
        apps.assist.setOnClickListener(v ->{
            Intent assist = new Intent(Settings.ACTION_VOICE_INPUT_SETTINGS);
                startActivity(assist); 
        });
        apps.perm.setOnClickListener(v ->{
            Intent perm = new Intent(this,PermManage.class);
                    startActivity(perm);
        });
        apps.apps456.setNavigationOnClickListener(v ->{
            onBackPressed();
        });
    }
}
