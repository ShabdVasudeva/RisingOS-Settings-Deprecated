package org.aospbased.settings;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import org.aospbased.settings.databinding.LayoutWallpaperStyleBinding;

public class WallpaperStyle extends AppCompatActivity {
    private LayoutWallpaperStyleBinding wall;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        wall = LayoutWallpaperStyleBinding.inflate(getLayoutInflater());
        setContentView(wall.getRoot());
        setSupportActionBar(wall.walls);
        wall.lockwall.setOnClickListener(v ->{
            Intent st = new Intent(this,lockwall.class);
                startActivity(st);
        });
        wall.homewall.setOnClickListener(v ->{
            Intent ho = new Intent(this,WallpaperChoose.class);
                startActivity(ho);
        });
        wall.personalisations.setOnClickListener(v ->{
            Intent pers = new Intent(this,Personalisation.class);
                startActivity(pers);
        });
    }
}
